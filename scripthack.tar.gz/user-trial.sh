#!/bin/bash
# Created by http://www.vps-murah.net
red='\e[1;31m'
green='\e[0;32m'
NC='\e[0m'
echo "Connecting to VPS-murah.net..."
sleep 0.2
echo "Checking Permision..."
sleep 0.3
CEK=`curl -s http://api.vps-murah.net/api/checker.php?mode=trial`;
if [ "$CEK" != "MEMBER" ]; then
		echo -e "${red}Permission Denied!${NC}";
        echo $CEK;
        exit 0;
else
echo -e "${green}Permission Accepted...${NC}"
sleep 1
clear
fi
clear
echo "Please Wait..."
sleep 0.5
echo "Generating Account..."
sleep 0.5
echo "Generating Host..."
sleep 0.5
echo "Generating Username..."
sleep 0.5
echo "Generating Password..."
sleep 1
MYIP=$(wget -qO- ipv4.icanhazip.com)
passrandom=$(cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 8 | head -n 1)

username=trial
egrep "^$username" /etc/passwd >/dev/null
if [ $? -eq 0 ]; then
# proses mengganti passwordnya
  echo -e "$passrandom\n$passrandom" | passwd $username
  clear
  echo " "
  echo "Script by vps-murah.net"
  echo "Terimakasih sudah berlangganan di vps-murah.net"
  echo " "
  echo "Demikian Detail Account Trial Anda"
  echo "------------------------------"
  echo "   Host     : $MYIP" 
  echo "   Username : $username"
  echo "   Password : $passrandom"
  echo "   Port     : 22,80,109,143,443"
  echo "------------------------------"
  echo " "
  
else
  useradd trial
  usermod -s /bin/false trial
  egrep "^$username" /etc/passwd >/dev/null
  echo -e "$passrandom\n$passrandom" | passwd $username
  clear
  echo " "
  echo "Script by vps-murah.net"
  echo "Terimakasih sudah berlangganan di vps-murah.net"
  echo " "
  echo "Demikian Detail Account Trial Anda"
  echo "------------------------------"
  echo "   Host     : $MYIP"
  echo "   Username : $username"
  echo "   Password : $passrandom"
  echo "   Port     : 22,80,109,143,443"
  echo "------------------------------"
  echo " "
fi