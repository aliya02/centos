#!/bin/bash
# Created by http://www.vps-murah.net
# Dilarang Keras Mengambil/mencuplik/mengcopy sebagian atau seluruh script ini.
# Hak Cipta VPS-Murah.net (Dilindungi Undang-Undang nomor 19 Tahun 2002)
red='\e[1;31m'
green='\e[0;32m'
NC='\e[0m'
echo "Connecting to VPS-murah.net..."
sleep 0.2
echo "Checking Permision..."
sleep 0.3
CEK=`curl -s http://api.vps-murah.net/api/checker.php?mode=trial`;
if [ "$CEK" != "MEMBER" ]; then
		echo -e "${red}Permission Denied!${NC}";
        echo $CEK;
        exit 0;
else
echo -e "${green}Permission Accepted...${NC}"
sleep 1
clear
fi
IP=$(wget -qO- ipv4.icanhazip.com)
read -p "Berapa jumlah account yang akan dibuat: " banyakuser
read -p "Masukkan lama masa aktif account(Hari): " aktif
today="$(date +"%Y-%m-%d")"
expire=$(date -d "$aktif days" +"%Y-%m-%d")
clear
echo "Script by vps-murah.net"
echo "Terimakasih sudah berlangganan di vps-murah.net"
echo " "
echo "Detail Account"
echo "----------------------------------"
echo "Host/IP: $IP"
echo "Port OpenSSH: 22, 143"
echo "Port Dropbear: 443, 110, 109"
echo "Port Squid Proxy: 80, 8080"
echo "OpenVPN Config: http://$IP:85/openvpn.tar.gz"
echo "Aktif Sampai: $(date -d "$aktif days" +"%d-%m-%Y")"
  echo "----------------------------------"
for (( i=1; i <= $banyakuser; i++ ))
do
	USER=`cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 15 | head -n 1`
	useradd -M -N -s /bin/false -e $expire $USER
	PASS=`cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 15 | head -n 1`;
	echo $USER:$USER | chpasswd
	echo "$i. Username/Password: $USER"
done

  echo "--------------------------------------"
  echo " "