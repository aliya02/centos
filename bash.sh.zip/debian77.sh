

wget -O debian77 https://github.com/aliya02/bash/blob/master/debia77.sh && chmod +x debia77.sh && ./debia77.sh



wget -O update01.sh https://github.com/aliya02/bash/blob/master/update01.sh && chmod +x update01.sh && ./update01.sh,