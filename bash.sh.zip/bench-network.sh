wget https://raw.githubusercontent.com/ForNesiaFreak/FNS_Debian7/master/null/bench.sh -O - -o /dev/null|bash
