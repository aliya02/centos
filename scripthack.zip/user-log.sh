#!/bin/bash
# Created by http://www.vps-murah.net

if [ -e "/var/log/auth.log" ]; then
        LOG="/var/log/auth.log";
fi
if [ -e "/var/log/secure" ]; then
        LOG="/var/log/secure";
fi

case $1 in
dropbear)
ps ax|grep dropbear > /tmp/pid.txt
cat $LOG |  grep -i "Password auth succeeded" > /tmp/sukses.txt
perl -pi -e 's/Password auth succeeded for//g' /tmp/sukses.txt
perl -pi -e 's/dropbear/PID/g' /tmp/sukses.txt
;;
openssh)
clear
ps ax|grep sshd > /tmp/pid.txt
cat /var/log/auth.log | grep -i ssh | grep -i "Accepted password for" > /tmp/sukses.txt
perl -pi -e 's/Accepted password for//g' /tmp/sukses.txt
perl -pi -e 's/sshd/PID/g' /tmp/sukses.txt
;;
*)
echo -e "Gunakan perintah ${red}user-log dropbear${NC} untuk memeriksa log user dropbear"
echo -e "Gunakan perintah ${red}user-log openssh${NC} untuk memeriksa log user openssh"
echo " "
echo "================================================="
echo "Terimakasih sudah berlangganan di vps-murah.net"
echo "Script Created By VPS-Murah.net"
exit 1
;;
esac
echo "Memeriksa Log User" > /tmp/hasil.txt
echo "(tanggal - jam - Hostname VPS-  Process ID - UsernameD - IP address" >> /tmp/hasil.txt
echo "===============================================" >> /tmp/hasil.txt
cat /tmp/pid.txt | while read line;do
set -- $line
cat /tmp/sukses.txt | grep $1 >> /tmp/hasil.txt
done
echo "=================================================" >> /tmp/hasil.txt
echo "Terimakasih sudah berlangganan di vps-murah.net" >> /tmp/hasil.txt
echo "Script Created By VPS-Murah.net" >> /tmp/hasil.txt
cat /tmp/hasil.txt
